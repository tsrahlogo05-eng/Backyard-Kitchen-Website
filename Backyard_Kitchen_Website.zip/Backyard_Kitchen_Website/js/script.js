document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".mobile-menu-button").forEach((button) => {
    const nav = document.getElementById(button.getAttribute("aria-controls"));
    if (!nav) return;
    button.addEventListener("click", () => {
      const open = nav.classList.toggle("is-open");
      button.setAttribute("aria-expanded", String(open));
    });
    nav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => {
      nav.classList.remove("is-open");
      button.setAttribute("aria-expanded", "false");
    }));
  });
  const search = document.getElementById("menu-search");
  const menuCards = Array.from(document.querySelectorAll(".menu-section"));
  const status = document.getElementById("menu-search-status");
  if (search && menuCards.length) {
    const updateMenu = () => {
      const term = search.value.trim().toLocaleLowerCase();
      let shown = 0;
      menuCards.forEach((card) => {
        const matches = card.textContent.toLocaleLowerCase().includes(term);
        card.hidden = !matches;
        if (matches) shown += 1;
      });
      if (status) status.textContent = term ? `${shown} menu section${shown === 1 ? "" : "s"} match your search.` : `Showing all ${shown} menu sections.`;
    };
    search.addEventListener("input", updateMenu);
    updateMenu();
  }
  const dialog = document.getElementById("image-dialog");
  const dialogImage = document.getElementById("dialog-image");
  const closeButton = document.getElementById("dialog-close");
  if (dialog && dialogImage) {
    document.querySelectorAll("main img.card-image, main img.menu-photo").forEach((img) => {
      img.tabIndex = 0;
      img.setAttribute("role", "button");
      img.setAttribute("aria-label", `Enlarge image: ${img.alt || "website image"}`);
      const open = () => {
        dialogImage.src = img.currentSrc || img.src;
        dialogImage.alt = img.alt;
        if (typeof dialog.showModal === "function") dialog.showModal();
      };
      img.addEventListener("click", open);
      img.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") { event.preventDefault(); open(); }
      });
    });
    closeButton?.addEventListener("click", () => dialog.close());
    dialog.addEventListener("click", (event) => { if (event.target === dialog) dialog.close(); });
  }
  const form = document.getElementById("contact-form");
  const formMessage = document.getElementById("form-message");
  if (form && formMessage) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      formMessage.hidden = false;
      formMessage.textContent = "Your details passed browser validation, but this demo form is not connected to a server and has not sent a message. Please call 083 755 8217, or connect a form service before publishing.";
      formMessage.setAttribute("role", "status");
    });
  }
});
